# Get git and python3 from apt-get
sudo apt-get update
sudo apt-get install git
sudo apt-get install python3

# Get the teffer grading script
git clone https://github.com/bddicken/teffer.git /autograder/source/teffer


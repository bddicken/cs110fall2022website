import prep19
print(prep19.multiply([10, 10, 3, 3, 2, 2, 4, 4]))


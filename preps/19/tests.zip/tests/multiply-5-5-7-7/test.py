import prep19
print(prep19.multiply([5, 5, 7, 7]))


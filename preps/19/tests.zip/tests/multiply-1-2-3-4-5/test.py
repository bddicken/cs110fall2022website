import prep19
print(prep19.multiply([1, 2, 3, 4, 5]))


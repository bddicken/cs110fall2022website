import prep19
print(prep19.multiply([1, 2, 2, 2, 2, 4, 2]))


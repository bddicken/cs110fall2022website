import prep16
print(prep16.calculate_distance(0, 0, 7, 7))


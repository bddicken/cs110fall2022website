import prep16
print(prep16.calculate_distance(5, 0, 20, 25))


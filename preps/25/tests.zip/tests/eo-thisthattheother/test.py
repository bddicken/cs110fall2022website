import prep25
result = prep25.every_other('this that the other')
print(result)


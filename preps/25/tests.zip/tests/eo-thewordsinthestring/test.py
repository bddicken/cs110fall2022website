import prep25
result = prep25.every_other('the words in the string')
print(result)


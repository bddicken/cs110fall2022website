import prep25
result = prep25.every_other('one fish two fish red fish blue fish')
print(result)


import prep37

grid = [[5, 4, 3, 2, 1],
        [1, 2, 3, 0, 0],
        [7, 2, 8, 1, 2],
        [1, 2, 1, 9, 0]]
result = prep37.get_highest_neighbor(grid, 1, 2)
print(result)


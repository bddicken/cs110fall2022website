import prep37

grid = [[5, 4, 3, 2],
        [1, 2, 0, 0],
        [5, 2, 1, 2],
        [1, 2, 1, 0]]
result = prep37.get_highest_neighbor(grid, 2, 1)
print(result)


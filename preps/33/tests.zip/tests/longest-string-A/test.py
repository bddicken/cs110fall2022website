import prep33

data = [{'a':'horse', 'b':'calculator'}, {'a':'camp', 'c':'joker'}]
result = prep33.longest_string(data)
print(result)


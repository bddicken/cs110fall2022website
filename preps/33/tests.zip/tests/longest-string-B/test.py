import prep33

data = [{1:'abc', 5:'onetwothree'}, {2:'abcd'}, {7:'one two three', 8:'one two three four', 5:'abc'}]
result = prep33.longest_string(data)
print(result)


import prep24
result = prep24.count_vowels('123abc123abc',5, 10)
print(result)


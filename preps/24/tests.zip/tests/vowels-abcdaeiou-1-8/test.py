import prep24
result = prep24.count_vowels('abcdaeiou', 1, 8)
print(result)


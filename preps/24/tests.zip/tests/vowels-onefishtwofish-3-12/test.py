import prep24
result = prep24.count_vowels('onefishtwofish', 3, 12)
print(result)


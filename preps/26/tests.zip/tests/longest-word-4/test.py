import prep26
word = prep26.longest_word("the big yellow elephant")
print(word)


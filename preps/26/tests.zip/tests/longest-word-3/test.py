import prep26
word = prep26.longest_word("a cat")
print(word)


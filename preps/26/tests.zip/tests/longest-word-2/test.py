import prep26
word = prep26.longest_word("the construction of the new building was time consuming")
print(word)


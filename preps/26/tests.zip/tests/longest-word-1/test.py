import prep26
word = prep26.longest_word("the word from the ocean by the town")
print(word)


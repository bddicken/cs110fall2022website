import prep29
result = prep29.differences({1, 2, 3}, {3, 4, 5})
print(result)


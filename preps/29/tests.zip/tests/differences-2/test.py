import prep29
result = prep29.differences({1, 2, 3}, {1, 2, 3, 4, 5, 6, 7, 8})
print(result)


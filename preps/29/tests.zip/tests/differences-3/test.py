import prep29
result = prep29.differences({'a', 'b', 'c', 'd'}, {'b', 'e', 'f', 'u', 'v', 'w'})
print(result)


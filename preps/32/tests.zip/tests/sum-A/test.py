import prep32

data = [[1, 2, 3], [12, 13, 4], [10, 5, 10, 5]]
number = prep32.sum_nums(data)
print(number)


import prep32

data = [[1, 2, 3], [4, 5, 6, 7], [8, 9, 11, 12, 20], [5, 1, 30], [4, 50, 5], [60, 1]]
number = prep32.sum_nums(data)
print(number)


import prep32

data = [[20, 30, 50, 60, 70], [3, 4], [1]]
number = prep32.sum_nums(data)
print(number)


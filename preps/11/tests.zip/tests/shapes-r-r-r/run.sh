cp TEST_DIR/test.py BASE_DIR/
cd BASE_DIR
python3 -u test.py

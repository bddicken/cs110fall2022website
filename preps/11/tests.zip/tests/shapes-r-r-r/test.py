import prep11

prep11.rectangle()
prep11.rectangle()
prep11.rectangle()

import prep17
words = 'Champion changes chosen chuze chin'
prep17.print_words_starting_with(words, 'c')


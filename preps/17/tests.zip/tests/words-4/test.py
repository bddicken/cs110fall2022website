import prep17
words = 'The short fellow over there'
prep17.print_words_starting_with(words, 't')


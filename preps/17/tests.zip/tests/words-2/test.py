import prep17
sentence = 'the big brown fox'
prep17.print_words_starting_with(sentence, 'b')



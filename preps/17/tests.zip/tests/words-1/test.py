import prep17
words = 'One of those old sterio systems was on sale.'
prep17.print_words_starting_with(words, 'o')


import prep22
prep22.most_common_vehicle('vehicle_file.txt')


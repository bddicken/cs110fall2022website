cat TEST_DIR/input.txt | python3 BASE_DIR/prep6.py

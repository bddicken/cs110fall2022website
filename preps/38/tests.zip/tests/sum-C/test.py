import prep38

grid = [[5, 4, 3, 2, 1],
        [1, 10, 20, 0, 0],
        [7, 2, 8, 1, 2],
        [1, 2, 1, 9, 0, 1, 2, 3, 1, 2, 3, 4, 1, 20, 30, 3]]
result = prep38.get_highest_sum(grid)
print(result)


import prep38

grid = [[5, 4, 3, 2, 1],
        [1, 10, 20, 0, 0],
        [7, 2, 8, 1, 2],
        [1, 2, 1, 9, 0]]
result = prep38.get_highest_sum(grid)
print(result)


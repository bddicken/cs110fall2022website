import prep38

grid = [[1, 2, 3, 4, 5], [7, 8, 1, 4, 2]]
result = prep38.get_highest_sum(grid)
print(result)


import prep28
result = prep28.count_calories({'orange':70, 'granola':100})
print(result)


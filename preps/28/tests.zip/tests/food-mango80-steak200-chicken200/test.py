import prep28
result = prep28.count_calories({'mango':80, 'steak':200, 'chicken':200})
print(result)


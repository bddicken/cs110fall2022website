import prep28
result = prep28.count_calories({'almond':100, 'peanut':120, 'walnut':130, 'pistachio':140})
print(result)


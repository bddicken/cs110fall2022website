import prep31

data = {'Alpha':10, 'bravo':25, 'charliE':15, 'dELTa':2}
numbers = prep31.get_elements(data, 12)
numbers.sort()
print(numbers)


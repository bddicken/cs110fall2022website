import prep31

data = {'O':110, 'R':253, 'A':151, 'D':20}
numbers = prep31.get_elements(data, 200)
numbers.sort()
print(numbers)


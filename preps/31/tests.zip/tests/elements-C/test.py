import prep31

data = {'echo':100, 'foxtroT':1000, 'golf':15, 'hotel':2}
numbers = prep31.get_elements(data, 500)
numbers.sort()
print(numbers)


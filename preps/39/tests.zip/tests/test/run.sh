cd BASE_DIR

python3 prep39.py


import prep20
ma, mi, a = prep20.grade_info([92.47, 95.01, 81.5, 88.3])
print(ma, mi, a)


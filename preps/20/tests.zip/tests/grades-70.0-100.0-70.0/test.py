import prep20
ma, mi, a = prep20.grade_info([70.0, 100.0, 70.0])
print(ma, mi, a)


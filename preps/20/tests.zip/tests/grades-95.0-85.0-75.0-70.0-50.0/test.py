import prep20
ma, mi, a = prep20.grade_info([95.0, 85.0, 75.0, 70.0, 50.0])
print(ma, mi, a)


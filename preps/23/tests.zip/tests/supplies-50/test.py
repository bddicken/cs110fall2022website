import prep23
prep23.get_supply_count()
f = open('total.txt')
print(f.readline())
f.close()


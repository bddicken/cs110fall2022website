cat TEST_DIR/input.txt | python3 -u BASE_DIR/prep10.py

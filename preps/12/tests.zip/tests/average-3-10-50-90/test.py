import prep12

prep12.average_numbers(4)

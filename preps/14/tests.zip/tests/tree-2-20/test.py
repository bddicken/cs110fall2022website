import prep14
print(prep14.calculate_tree_height(2, 20))


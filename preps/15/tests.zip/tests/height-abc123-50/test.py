import prep15
print(prep15.get_height_category('abc123', 50))


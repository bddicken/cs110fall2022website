import prep15
print(prep15.get_height_category('female', 63))


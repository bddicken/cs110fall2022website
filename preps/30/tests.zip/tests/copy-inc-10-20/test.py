import prep30

values = [10, 20]
result = prep30.copy_and_increment(values)
print('List passed into function:     ', values)
print('List returned by function call:', result)


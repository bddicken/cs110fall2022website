import prep30

values = [3, 4, 5, 6, 7, 8, 9]
result = prep30.copy_and_increment(values)
print('List passed into function:     ', values)
print('List returned by function call:', result)


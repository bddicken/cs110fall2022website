import prep21
two_results = prep21.two_words(['tree', 'yelp', 'rodger', 'tank', 'terrain'])
print(two_results)


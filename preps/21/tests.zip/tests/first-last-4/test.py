import prep21
two_results = prep21.two_words(['insanity', 'elephant'])
print(two_results)


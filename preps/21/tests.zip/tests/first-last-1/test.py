import prep21
two_results = prep21.two_words(['tree', 'forest', 'antelope', 'zebra'])
print(two_results)


import prep18
print(prep18.multiply([1, 2, 3, 4, 5]))


import prep18
print(prep18.multiply([1, 2, 2, 2, 2, 4, 2]))


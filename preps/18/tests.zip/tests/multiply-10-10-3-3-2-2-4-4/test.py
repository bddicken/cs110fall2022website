import prep18
print(prep18.multiply([10, 10, 3, 3, 2, 2, 4, 4]))


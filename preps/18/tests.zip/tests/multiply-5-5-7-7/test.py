import prep18
print(prep18.multiply([5, 5, 7, 7]))


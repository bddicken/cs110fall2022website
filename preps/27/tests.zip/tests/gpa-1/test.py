import prep27
result = prep27.get_gpa({'cs120':2.0, 'cs210':4.0, 'cs245':4.0})
print(result)


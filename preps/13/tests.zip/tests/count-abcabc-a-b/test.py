import prep13

prep13.count_characters('abcabc', 'a', 'b')

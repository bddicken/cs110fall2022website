import prep13

prep13.count_characters('the deep blue sea', 'e', 'a')

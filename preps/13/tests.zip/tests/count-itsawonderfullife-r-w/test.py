import prep13

prep13.count_characters('its a wonderful life', 'r', 'w')
